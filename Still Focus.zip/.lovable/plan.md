## Read the brief — locked in

Hackathon theme: agents that **remember and act on memory** across sessions, with **HydraDB as the primary memory layer**. "still." fits the **Open Memory Track** (also adjacent to Smart Journal Analyst, since parked notes accrete over time). The personalization moments in your brief — "Last time the big tasks stalled", "You focus best around 10am", recurring parked-thought detection — are exactly the context-aware-execution proof the judges want.

## Security heads-up

You pasted a live `sk_live_…` key in chat earlier. **Rotate it in dashboard.hydradb.com now.** I'll request the new one through the secure secret form (never via chat).

## HydraDB integration shape (from docs)

- Base URL `https://api.hydradb.com`, `Authorization: Bearer <HYDRA_DB_API_KEY>`, `API-Version: 2`.
- Core endpoints: `POST /tenants` → `POST /context/ingest` (type `"memory"`) → `POST /query` (type `"memory"`).
- Per-user isolation via **sub-tenants** (one tenant for the app, one sub-tenant per signed-in user).
- All calls run **server-side** (TanStack server functions) so the API key never reaches the browser.

## Plan

### 1. Auth (Lovable Cloud, minimal)

Email magic-link sign-in. Cloud only provides `auth.users.id` — that's the only thing stored there. **All memory lives in HydraDB.** This satisfies the brief's "HydraDB as the primary memory, context-retrieval, and storage layer."

### 2. Secrets

- `HYDRA_DB_API_KEY` (server-only, via secure secret form)
- `HYDRA_DB_TENANT_ID` (auto-provisioned on first boot via `POST /tenants`, cached as a secret)

### 3. `src/lib/memoryClient.ts` — the single swap point

UI never touches HydraDB directly. The client calls TanStack server functions which call HydraDB. Methods:

- `saveTask(text)` → ingest as memory with metadata `{kind:"task", word_count, created_at}`
- `markTaskComplete(taskId)` → ingest follow-up memory `{kind:"task_complete", ref:taskId}`
- `logBlock({duration, startedAt, completedAt})` → ingest `{kind:"block", ...}`
- `savePark(text)` → ingest `{kind:"park", created_at}`
- `getPersonalization()` → **single call** that runs HydraDB queries and returns:
  - `isReturning`
  - `suggestedTask` (small past task surfaced via `/query` semantic search for "small starter task")
  - `stalledLongTasksHint` (computed from recent task word-counts + missing completion)
  - `peakHourLine` (e.g. "You focus best around 10am — 7 blocks done there.")
  - `totalBlocks`, `todayBlocks`
  - `recurringParkTheme` (HydraDB `/query` over parked notes; surfaces a cluster if found)
- `getParkHistory(limit)` → list parked notes for the in-app list under the input.

Server functions live in `src/lib/hydra.functions.ts`; raw HTTP helper in `src/lib/hydra.server.ts` (server-only).

### 4. UI — single 540px column, four cards

Route `src/routes/_authenticated/index.tsx`; public `/auth` for magic link. On mount: `getPersonalization()` fires once and visibly changes the screen for returning users (hint copy, suggested task chip, stats line, "welcome back — N blocks so far").

1. **The one thing** — input + button. Personalized hint chosen from `getPersonalization()` per your brief's rules.
2. **Begin** — full-screen 5→4→3→2→1→"go." overlay, then auto-starts timer.
3. **Focus block** — 15 / 25 toggle, timer, standing reminder. On complete: `logBlock`, "That's a rep.", peak-hour line refreshes.
4. **Park it** — input, Enter saves with timestamp. List below. If `recurringParkTheme` is non-null, quiet line above the list: "This thought keeps coming back."

Footer line verbatim from brief.

### 5. Design tokens (`src/styles.css`)

- bg `#1a1d23`, primary sage `#8fb4a8`, secondary tan `#d4a373`, warm off-white foreground, low-contrast borders.
- `--radius: 14px`. Generous spacing.
- Fonts via `@fontsource/lora` (serif headings) + system sans body. Installed with `bun add`, imported in entry, registered in `@theme`.

### 6. Hackathon deliverables baked in

- **Execution logs**: `src/routes/_authenticated/memory-log.tsx` — a hidden debug panel (toggle via `?logs=1`) that shows the last N HydraDB ingest/query traces (timestamps, endpoints, returned IDs). Lets you show judges the agent autonomously wrote to and queried HydraDB.
- **README section** documenting the HydraDB integration, sub-tenant model, and the personalization decisions driven by `/query` results — for the source-code deliverable.
- Submission code `MEMORY2026` and promo `HYDRA2026` noted in README for your reference.

## Build order

1. Enable Lovable Cloud, configure email magic-link auth, `_authenticated` gate.
2. Add `HYDRA_DB_API_KEY` secret (secure form).
3. Implement `hydra.server.ts` + tenant bootstrap server fn.
4. Implement `memoryClient` + `hydra.functions.ts` (ingest + query wrappers, per-user sub-tenant).
5. Build the four UI cards with the design tokens.
6. Wire `getPersonalization()` on mount; verify a returning user sees something a first-timer doesn't.
7. Add the debug log panel and README.

## Out of scope

Badges, streaks, push notifications, multi-screen nav, social features.

---

Approve and I'll build it. If you'd rather I integrate HydraDB only partially (e.g. parks-only) to fit the 8-hour window tighter, tell me — otherwise I'll do the full plan above.